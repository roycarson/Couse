# Introduction

Your first step to becoming a fully-fledged web developer is now behind you!

The Makers Academy course is a very intense 12 week long immersion course. This course is a balance between you taking responsibility for your own education, letting the coaches know what your needs are and supporting your fellow students during the course in all the needs they might have.

During this pre course phase you will be learning a few of these things as well as getting yourself used to guided self study. It might get confusing and frustrating at times, but that is all part of the process.

**You are expected to be working for 15-20 hours a week for the next 4 weeks (that is before your official start date at Makers Academy).**
