class Bike

  def working?
  	true
  end

end
