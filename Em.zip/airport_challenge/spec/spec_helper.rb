require 'coveralls'
Coveralls.wear!
