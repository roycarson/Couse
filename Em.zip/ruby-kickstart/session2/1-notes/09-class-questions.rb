# Between Yankees and Baseball team
# which is a class and which is an instance?

# Between Person and Enoch
# which is a class and which is an instance?

# Can you think of another class and several instances?



# Are classes objects?
# If no, where do you think their methods are stored?
# If yes, what class are they instances of?
