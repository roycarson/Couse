# Okay, ready for challenges ^_^
# I spent a long time on these, hopefully you'll enjoy them!



# A USEFUL HINT!
# You can return from a method early with the keyword return
def method(condition)
  return 1 if condition
  2
end
method true  # => 1
method false # => 2

# Check out cheatsheet for arrays:
# https://github.com/JoshCheek/ruby-kickstart/blob/master/cheatsheets/arrays.rb