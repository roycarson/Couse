number = 5
other_number = 12

puts "first line" , "second line"

puts "The number we have is #{number} and the sum of our numbers is #{number + other_number}" 
# >> The number we have is 5 and the sum of our numbers is 17

print "this will all be "
print "on the same line"

puts # an empty newline
