# run me by using cd to get to my directory
# then type $ ruby 1_first_program.rb

puts "Hello reader."
puts "Welcome to Ruby"

puts "Lets demonstrate a simple calculation"
answer = 2 + 2
puts "2 plus 2 is #{answer}"

