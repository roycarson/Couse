def arithmetic2(a, b)
  if a < b
    a / 2.0
  else
    b / 2.0
  end
end
