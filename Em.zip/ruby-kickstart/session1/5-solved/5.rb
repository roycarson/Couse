def add_more_ruby(string)
  string.gsub('sad', 'happy').gsub('Sad', 'Happy')
end
