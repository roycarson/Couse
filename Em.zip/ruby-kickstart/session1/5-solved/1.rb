def arithmetic1(n)
  n * 5 - 20
end