def ten_twenty(n)
  if n % 2 == 0
    10
  else
    20
  end
end
