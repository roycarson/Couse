# You can use basic operators on Strings, just like other objects:

my_string   = "Face"
your_string = "book"

my_string + your_string  # => "Facebook"

my_string == your_string # => false
my_string = "book"
my_string == your_string # => true

