Python
======
<p align="center">
[![Python Talk][2]][1]
<br/>
Introduction to Python (44mins)
<p>

  [1]: https://www.youtube.com/watch?v=jwgqY_IcrJg
  [2]: https://i.ytimg.com/vi/jwgqY_IcrJg/hqdefault.jpg?time=1416606788295

Resources
------
* [Google's Python Intro Course](https://developers.google.com/edu/python/)
* [Sure (Python's RSpec)](https://github.com/gabrielfalcao/sure)
* [Lettuce (Python's Cucumber)](https://github.com/gabrielfalcao/lettuce)
* [Flash (Python's Sinatra)](http://flask.pocoo.org/)
* [Django (Python's Rails)](https://docs.djangoproject.com/en/1.7/intro/tutorial01/)
