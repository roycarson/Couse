Having completed this pill you should have a reasonable understanding of a basic Sinatra app.

Exercises
--------

* :running_shirt_with_sash: Try recreating this app without referring to the pill
* Try recreating this app but with a different image and generating a different sort of text rather than a greeting, e.g. answering a simple question that ruby can answer, like is this string a number?