# Engineering the Unixoid Challenge

Some of the engineers employed at Makers Academy worked on re-factoring the Unixoid Challenge, turning a "spike" into a test-driven gem.

[Video of talk on this](https://www.youtube.com/watch?v=pSwWowBmyG0)

[Github](https://github.com/makersacademy/unixoid-challenge) - feel free to fork this repository, the Gem is completely open-source!

