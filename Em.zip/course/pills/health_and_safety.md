Health and Safety - a very broad outline
========

“If your mum would disapprove, it's probably best to save it for when you're not in the office.” - Jordan Poulton

FIRE SAFETY
------

* Smoking is not permitted anywhere within the building

* Don’t overload power lines. Do not use or bring to the office faulty electrical equipment. Report any faults to a member of staff.

* Keep fire exits closed at all times

In the event of a fire:

* Follow the fire exit signs to vacate the building

* Follow the instructions of the Fire Marshals (Ana, Dana, Steve and Nikesh) to leave the building, fire exit signs and do not use lifts

* Assembly point is in the corner of Thrawl street and Commercial Street - Turn right out of door

FIRST AID
--------

* If somebody gets injured, get help from one of the first aiders - Ana, Nikesh
