Working in Teams
===============

:construction: UNDER CONSTRUCTION :construction:

* Planning
* Scrums 
* Reflection
* Working around interfaces
* Handling merge conflicts
* Handling interpersonal conflicts
