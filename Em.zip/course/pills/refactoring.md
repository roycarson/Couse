Refactoring 
==========

:construction: UNDER CONSTRUCTION :construction:

Refactoring is the process of adjusting code to remove code smells.  It is about keeping the functionality the same but adjusting the code to be more readable, maintainable, and flexible.

In the meantime you should totally read this book:

http://www.amazon.co.uk/Refactoring-Edition-Addison-Wesley-Professional-Series/dp/0321984137

but coming soon will be:

* extract method
* extract class
* and lots more
