Instagram Marketplace
=========

***UNDER CONSTRUCTION***

... in the meantime please find individual walkthroughs below for reference:

***As you've heard before all Makers Academy materials may include subtle errors.  Please try to approach those as challenges on which to polish your debugging skills - pull requests always welcome.***

* [WebSockets](https://github.com/makersacademy/course/blob/master/walkthroughs/websockets.md)
* [Heroku](https://github.com/makersacademy/course/blob/master/walkthroughs/heroku.md)
* [Stripe](https://github.com/makersacademy/course/blob/master/walkthroughs/stripe.md)
* [Email](https://github.com/makersacademy/course/blob/master/walkthroughs/email.md)
* [Maps](https://github.com/makersacademy/course/blob/master/walkthroughs/gmaps.md)
* [OmniAuth](https://github.com/makersacademy/course/blob/master/walkthroughs/devise_omniauth.md)
