# sessions_example

Code from the lecture on Weds 18th Feb 2015 with Mihai
