-1. need to do create, showing form etc. 	

0. Any questions (Cmd-P)

1. demonstrate that hard coding breaks 

2. raise error in create (show debugging info in browser, what is the session, hash data is just what we need for create)

3. demonstrate form spamming

4. secrets.yml - authenticity token

5. fix hard coding breaks

6. formatting for restaurants 

7. create editing test

8. first route with variable,  talking about ids on database

9. show link_to, edit_restaurant_path

10. add edit method

11. show partials

12. make edit method work

13. test for deleting (DELETE HTTP verb)

14. making that pass

15. flash to indicate the delete (application.html.erb)

16. application.js --> remove turbo links

17. javascript confirmation


18. making apps in a resource based way (REST) only using those verbs in routes
